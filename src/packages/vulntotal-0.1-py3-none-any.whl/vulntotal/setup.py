from setuptools import setup, find_packages

setup(
    name='datasources',
    version='0.1',
    packages=['datasources'],
)