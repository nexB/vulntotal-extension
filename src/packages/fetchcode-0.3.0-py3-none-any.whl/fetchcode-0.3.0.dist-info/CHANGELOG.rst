Changelog
=========


v0.3.0
-------
- Add `package_versions` for retrieving all released versions of a given package.


v0.2.0
-------

- Don't delete temp directory in fetch_via_vcs

v0.1.0
---------

First, initial release.
 