import gitlab.cli

if __name__ == "__main__":
    gitlab.cli.main()
